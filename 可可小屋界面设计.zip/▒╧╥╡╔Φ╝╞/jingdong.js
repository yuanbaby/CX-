/**
 * Created by samsung on 2016/4/26.
 */
/*鼠标划过，出现地点*/
$(function(){
    $(".tit1").mouseover(function(){
        $("#ti2").css("display","block");
    })
});
$(function(){
    $(".tit1").mouseout(function(){
        $("#ti2").css("display","none");
    })
});
/*选择购物地点*/
$(function(){
    $("#ti2 li").click(function(){
       $("#ti2 li").removeClass();
        $(this).addClass("bg");
        $(".ti1 a").html($(this).html());
    });

});
/*top鼠标划过出现*/
$(function(){
    $("#a1").mouseover(function(){
        $("#a1 img").css("display","block");

    })
});
$(function(){
    $("#a1").mouseout(function(){
        $("#a1 img").css("display","none");

    })
});
$(function(){
    $("#a2").mouseover(function(){
        $("#a2 img").css("display","block");

    })
});
$(function(){
    $("#a2").mouseout(function(){
        $("#a2 img").css("display","none");

    })
});
$(function(){
    $("#a3").mouseover(function(){
        $("#a3 img").css("display","block");

    })
});
$(function(){
    $("#a3").mouseout(function(){
        $("#a3 img").css("display","none");

    })
});
$(function(){
    $("#a4").mouseover(function(){
        $("#a4 img").css("display","block");

    })
});
$(function(){
    $("#a4").mouseout(function(){
        $("#a4 img").css("display","none");

    })
});
$(function(){
    $("#a5").mouseover(function(){
        $("#a5 img").css("display","block");

    })
});
$(function(){
    $("#a5").mouseout(function(){
        $("#a5 img").css("display","none");

    })
});
/*获取焦点value值消失*/
function v1(){
    var val = $("#top1 input");
    $(val).attr({placeholder:""});
}
function v2(){
    var val = $("#top1 input");
    $(val).attr({placeholder:" 全场狂欢"});
}

//购物车
function gw(){
    var pic = document.getElementById("img1");
    var pic1 = document.getElementById("img2");
    pic.style.borderBottom = "none";
    pic1.style.display = "block";
    pic1.style.boxShadow = "2px 2px 9px #dfdfdf";

}
function gw1(){
    var pic = document.getElementById("img1");
    var pic1 = document.getElementById("img2");
    pic.style.borderBottom = "1px solid #dfdfdf";
    pic1.style.display = "none";
}

/*header左边部分*/
function l1(a){
    var div = document.getElementById("list").getElementsByTagName("img");
    var list = document.getElementById("list").getElementsByTagName("li");
    for( var i=0; i<div.length; i++){
        div[i].style.display = "none";
    }
    for (var k=0; k<list.length; k++){
        list[k].style.backgroundColor="#c81623";
        list[k].style.color="white";
    }
    div[a].style.display = "block";
    list[a].style.backgroundColor="#f7f7f7";
    list[a].style.color="red";
}
function l2(a) {
    var div = document.getElementById("list").getElementsByTagName("img");
    var list = document.getElementById("list").getElementsByTagName("li");
    for (var i = 0; i < div.length; i++) {
        div[i].style.display = "none";
    }
    for (var k = 0; k < list.length; k++) {
        list[k].style.backgroundColor = "#c81623";
        list[k].style.color = "white";
    }

}
/*banner图片轮播*/
var col=0;
function banner1(){
    var arr = ["img/banner1.jpg", "img/banner2.jpg", "img/banner3.jpg", "img/banner4.jpg"];
    var img2 = document.getElementById("ban");
    var list1 = document.getElementById("list1").getElementsByTagName("li");
    for( var e = 0; e<list1.length; e++){
        list1[e].style.backgroundColor = "#dcdcdc";
        list1[e].style.color = "#000";
    }
    list1[col].style.backgroundColor = "red";
    list1[col].style.color = "white";
    img2.src = arr[col];
    col++;
    if (col >= arr.length) {
        col = 0;
    }
}
function banner2(ba){
    col=ba;
    clearInterval(tt);
    banner1();
    tt=setInterval("banner1()",1000);
}
var tt = setInterval("banner1()",1000);

var j = 0;
function banner() {
    var arr = ["img/banner1.jpg", "img/banner2.jpg", "img/banner3.jpg", "img/banner4.jpg"];
    var img2 = document.getElementById("banner").getElementsByTagName("img");
    var left1 = document.getElementById("left1");
    var right1 = document.getElementById("right1");

    left1.onclick = function () {
        col = j;
        clearInterval(tt);
        banner1();
        tt = setInterval("banner1()",1000);
        j == 0 ? j = arr.length - 1 : j--;
        img2.src = arr[j];
    };
    right1.onclick = function () {
        col = j;
        clearInterval(tt);
        banner1();
        tt = setInterval("banner1()",1000);
        j == arr.length - 1 ? j = 0 : j++;
        img2.src = arr[j];
    }
}
/*鼠标划过话费出现话费一栏*/
$(function(){
    $("#rig2 li").mouseover(function(){
        $("#rig2 li").css("display","none");
        $("#ld").css({ display:"block"})
    })
})
//header右边选项框
$(function(){
    $("#rig3 li").click(function(){
        $("#rig3 li").css("borderBottom","1px solid #dcdcdc");
        $(this).css("borderBottom","none");
        $("#rig3 li img").css("display","none");
        var img = $(this);
        var img1 = $(img).children();
        $(img1).css("display","block");

    })
});
/*鼠标划过换一批，红线出现*/
$(function(){
    $(".h1").mouseover(function(){
        $(".h1 a").css("color","red");
        $(".hh").css("display","block");
        $(".hh").animate({left:"1100px"},500).animate({left:"-1100px"},500);
    })
})
$(function(){
    $(".h1").mouseout(function(){
        $(".h1 a").css("color","black");
        $(".hh").css("display","none");
    })
})
/*换一批*/
    var arr = [
        [{src:"img/h1.gif"} ,{src:"img/h2.gif"},{src:"img/h3.gif"},{src:"img/h4.gif"} ,{src:"img/h5.gif"},{src:"img/h6.gif"}],
        [{src:"img/h4.gif"} ,{src:"img/h3.gif"},{src:"img/h6.gif"},{src:"img/h1.gif"} ,{src:"img/h2.gif"},{src:"img/h5.gif"}],
        [{src:"img/h4.gif"} ,{src:"img/h6.gif"},{src:"img/h2.gif"},{src:"img/h5.gif"} ,{src:"img/h3.gif"},{src:"img/h1.gif"}],
        [{src:"img/h3.gif"} ,{src:"img/h5.gif"},{src:"img/h1.gif"},{src:"img/h2.gif"} ,{src:"img/h6.gif"},{src:"img/h4.gif"}],
    ];
    var j = 1;
    function huan(){
        var ss = $("#main4 li img");
        for(var i = 0; i<ss.length; i++){
            $(ss[i]).attr(arr[j][i]) ;//ss[i].src = arr[j][i].src;;
        }
        j++;
        if(j>=arr.length){
            j=0;
        }
}
/*鼠标划过加蒙版*/
function tl(name,m) {

    var img2 = document.getElementById(name+m);
    img2.style.display = "block";
}

function tk(name, m) {
    var img2 = document.getElementById(name+m);
    img2.style.display = "none";
}
/*鼠标划过图片变大并加边框*/
function fd(img){
    img.style.width = 200+"px";
    img.style.height = 200+"px";
    img.style.border = "1px solid #dcdcdc";
}
function sx(img){
    img.style.width = 200+"px";
    img.style.height = 200+"px";
    img.style.border = "none";
}
//鼠标划过图片向左移动
$(function(){
    var i = 0;
    $("#left2").click(function(){
        var left = $("#right2").css("left");
        left = parseInt(left)-245+"px";
        var length = $("#right2 img").length;
        if(i<length-4){
            i++;
            $("#right2").animate({"left":left});
        }
    });
    $("#right3").click(function(){
        var left = $("#right2").css("left");
        left = parseInt(left)+245+"px";
        if(i>0){
            i--;
            $("#right2").animate({left:left});
        }
    })
});
/*1F中的图片轮播*/
var tp =1;
var h = null;
function img1(){
    var arr = ["img/d.png","img/d1.png","img/d2.png","img/d3.png"];
    $("#img3").attr("src",arr[tp]);
    var list = $("#list2 li").removeClass();
    $(list[tp]).addClass("bg");
    tp++;
    if(tp>=arr.length){
        tp=0;
    }
}
function img2(j){
    i = j;
    clearInterval(h);
    img1();
    h = setInterval("img1()",1500);
}
h = setInterval("img1()",1500);
/*1F中的图片滑动效果*/
function fade2(k) {
    var dt = $(".lt2 #rt2 img");
    $(dt[k]).fadeTo("slow", 0.08).fadeIn("slow", 1);
}

/*1F中的选项框效果*/
$(function(){
    $(".rt1 li").click(function(){
        $(".rt1 li").css({borderLeft:"none",borderTop:"none",borderRight:"none",borderBottom:"1px solid #c81623",color:"black"});
        $(this).css({borderTop:"2px solid #c81623",borderLeft:"1px solid #c81623",borderRight:"1px solid #c81623",borderBottom:"none",color:"#c81623"});
        $(".rt1 .lt2").css("display","none");
        var img = $(this);
        $(img).children(".lt2").css("display","block");

    })
});
/*2F中的选项框效果*/
$(function(){
    $(".rt2 li").click(function(){
        $(".rt2 li").css({borderLeft:"none",borderTop:"none",borderRight:"none",borderBottom:"1px solid #c81623",color:"black"});
        $(this).css({borderTop:"2px solid #c81623",borderLeft:"1px solid #c81623",borderRight:"1px solid #c81623",borderBottom:"none",color:"#c81623"});
        $(".rt2 .lt").css("display","none");
        var img = $(this);
        $(img).children(".lt").css("display","block");

    })
});
/*3F中的选项框效果*/
$(function(){
    $(".rt3 li").click(function(){
        $(".rt3 li").css({borderLeft:"none",borderTop:"none",borderRight:"none",borderBottom:"1px solid #c81623",color:"black"});
        $(this).css({borderTop:"2px solid #c81623",borderLeft:"1px solid #c81623",borderRight:"1px solid #c81623",borderBottom:"none",color:"#c81623"});
        $(".rt3 .lt3").css("display","none");
        var img = $(this);
        $(img).children(".lt3").css("display","block");

    })
});
/*4F中的选项框效果*/
$(function(){
    $(".rt4 li").click(function(){
        $(".rt4 li").css({borderLeft:"none",borderTop:"none",borderRight:"none",borderBottom:"1px solid #c81623",color:"black"});
        $(this).css({borderTop:"2px solid #c81623",borderLeft:"1px solid #c81623",borderRight:"1px solid #c81623",borderBottom:"none",color:"#c81623"});
        $(".rt4 .lt4").css("display","none");
        var img = $(this);
        $(img).children(".lt4").css("display","block");

    })
});
/*5F中的选项框效果*/
$(function(){
    $(".rt5 li").click(function(){
        $(".rt5 li").css({borderLeft:"none",borderTop:"none",borderRight:"none",borderBottom:"1px solid #c81623",color:"black"});
        $(this).css({borderTop:"2px solid #c81623",borderLeft:"1px solid #c81623",borderRight:"1px solid #c81623",borderBottom:"none",color:"#c81623"});
        $(".rt5 .lt5").css("display","none");
        var img = $(this);
        $(img).children(".lt5").css("display","block");

    })
});
/* 右边灰色小边*/
$(function(){
    $("#ht1 li").mouseover(function(){
        $(this).children(".test2").css({ display:"block", left:"-60px"});
       $(this).children(".test2").html();
    });
    $("#ht1 li").mouseout(function(){
        $(this).children(".test2").css({ display:"none", left:"60px"});
    })
});
$(function(){
    $("#ht2 li a").mouseover(function(){
        $(this).children(".tes1").css({ display:"block", left:"-60px"});
        $(this).children(".tes1").html();
    });
    $("#ht2 li a").mouseout(function(){
        $(this).children(".tes1").css({ display:"none", left:"60px"});
    })
});
/*鼠标划过楼层*/
var arr2 = ["电器","美妆","手机","数码","家用"];
var arr3 = ["1F","2F","3F","4F","5F"];
function bian(i){
    var list = $("#floor li");
    list[i].innerHTML = arr2[i];
    list[i].style.color = "white";
    list[i].style.background = "red";
}
function bian1(i){
    var list = $("#floor li");
    list[i].innerHTML = arr3[i];
    list[i].style.color = "";
    list[i].style.background = "";
}
/*楼层效果*/
var arr1 = [];
$(function (){
 var step = $("#FF .floor");
    step.each(function(i){
        arr1[i] = $(step[i]).offset().top;
    })
 });
$(window).scroll(function(){
    var top = $(window).scrollTop();
    var height = $(window).height();
    if(top >= 2120-height){
        $("#floor").show();
    }else{
        $("#floor").hide();
    }
    for( var j=0; j<arr3.length; j++){
        $("#floor li:eq("+ j +")").html(arr3[j]);
    }
    $("#floor li").css({color:"#000",background:""});
    for( var i =0; i < arr1.length; i++){
        if(top <= arr1[i]){
            $("#floor li:eq("+ i +")").css({color:"white",background:"red"});
            $("#floor li:eq("+ i +")").html(arr2[i]);
            break;
        }
    }
});
/*fuzhuang页面*/
/*左边列表鼠标滑过出现*/
function show1(){
        $("#top3 .list").css("display","block");
    }
function delete1(){
        $("#top3 .list").css("display","none");
}
/*小图换大图*/
function change(g){
       var picture1 = $("#abbbbb");
        picture1.attr("src",g.src);
}
/*鼠标滑过出现关注*/
$(function(){
    $("#nav1 .main1 .img1 ").mouseover(function(){
        $("#nav1 .main1 .guanzhu").css("display","block");
    });
});
$(function(){
    $("#nav1 .main1 .img1 ").mouseout(function(){
        $("#nav1 .main1 .guanzhu").css("display","none");
    })
});
/*鼠标滑过关注变红*/
$(function() {
    $("#nav1 .main1 .guanzhu ").mouseover(function () {
        $("#nav1 .main1 .guanzhu img").attr("src","img/taobao3r.gif");
        $("#nav1 .main1 .guanzhu .span5").css("color", "red");
    })
});
$(function() {
    $("#nav1 .main1 .guanzhu ").mouseout(function () {
        $("#nav1 .main1 .guanzhu img").attr("src","img/taobao3.gif");
        $("#nav1 .main1 .guanzhu .span5").css("color", "white");
    })
});
/*综合，销量排序*/
function sort(a){
    var div = document.getElementById("right").getElementsByTagName("article");
    var list = document.getElementById("right").getElementsByTagName("li");
    for( var i=0; i<div.length; i++){
        div[i].style.display = "none";
    }
    for( var j=0; j<list.length; j++){
        list[j].style.color="black";
        list[j].style.background="#f7f7f7";
    }
    div[a].style.display="block";
    list[a].style.color="#ffffff";
    list[a].style.background="#ff0000";
}
/*连衣裙页面*/
/*小图换大图*/
function s1(sp){
    var btt = document.getElementById("pic");
    var spic = document.getElementById("ul").getElementsByTagName("img");
    btt.src = spic[sp].src;
}
/*选择尺码*/
    function size1(ii){
        $("#ul1 li").removeClass();
        $(ii).toggleClass("border1");
    }
/*选择分期*/
function size2(ii){
    $("#ul2 li").removeClass();
    $(ii).toggleClass("border1");
}
/*商品介绍*/
function dj(a){
    var div = document.getElementById("nav41").getElementsByTagName("article");
    var list = document.getElementById("ul3").getElementsByTagName("li");
    for( var i=0; i<div.length; i++){
        div[i].style.display = "none";
    }
    for( var j=0; j<list.length; j++){
        list[j].style.color="black";
        list[j].style.background="#f7f7f7";
    }
    div[a].style.display="block";
    list[a].style.color="#ffffff";
    list[a].style.background="#ff0000";
}
/*用户进行评价*/
var jj = 0;
function text(){
    var name = $("#name1");
    var cont = $("#text1");
    if(name.val() == ""){
        alert("请进行登录！");
    }else
    if(cont.val() == ""){
        alert("请输入评价内容！")
    }else{
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth()+1;
        var date1 = date.getDate();
        var hour = date.getHours();
        var min = date.getMinutes();
        var second = date.getSeconds();
        var div = $("#b div");
        $(div[0]).html(name.val());
        $(div[1]).html(cont.val());
        $(div[2]).html((year +"-"+month +"-"+date1+" "+hour+":"+min+":"+second));
        var content = $(".spj");
        var b = $("#b").clone(true);
        content.append(b);
        b.css("display","block");
        b.id = "b"+jj;
        jj++;

    }
};
/*放大镜效果*/
function larger(obj,zhi){
    $("#fd").show();
    var x = zhi.clientX;
    var y = zhi.clientY;
    $("#large").attr("src",obj.src);
    $("#large").css("left",-x*2);
    $("#large").css("top",-y*2);
}
function smaller(){
    $("#fd").hide();
}
/*计数*/
$(function(){
    var co = $("#js").val();
    $("#button1").click(function(i){
        co++;
        $("#js").attr("value",co);
    });
    $("#button2").click(function(i){
        co--;
        if(co < 0){
            co = 0;
        }else{
            $("#js").attr("value",co);
        }
    });
});
/*注册界面*/
function zy(){
    var na = document.getElementById("na");
    var reg = /((a-z)||(A-Z))/;
    if(na.value.length>0 && na.value.length<=8){
        if(reg.test(na.value)){

        }
    }else{
        alert("请输入正确的用户名！")
    }
}
/*登陆界面*/
function dy(){
    var yhm = $("#input1");
    var qsr = $("#span1");
    $(qsr).html("请输入用户名！");
    $(qsr).css({ color:"#3e3e3e"})
}
function dy1(){
    var yhm = $("#input1");
    var qsr = $("#span1");
    $(qsr).css("display","none");
}