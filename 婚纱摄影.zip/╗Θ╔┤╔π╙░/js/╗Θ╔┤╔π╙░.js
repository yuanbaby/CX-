/**
 * Created by samsung on 2016/4/26.
 */
/*首页的图片轮播*/
var i=0;
var j = 0;
function change() {
    var arr = ["img/left2.jpg","img/left5.jpg","img/left1.jpg","img/left7.jpg"];
    var img = document.getElementById("img");
    var left1 = document.getElementById("left1");
    var right1 = document.getElementById("right1");

    left1.onclick =  function () {
        i = j;
        clearInterval(tt);
        get_Picture();
        tt = setInterval("get_Picture()",1000);
        j == 0 ? j = arr.length - 1 : j--;
        img.src = arr[j];

    };
    right1.onclick = function () {
        i = j;
        clearInterval(tt);
        get_Picture();
        tt = setInterval("get_Picture()",1000);
        j == arr.length - 1 ? j = 0 : j++;
        img.src = arr[j];
    }
}
function get_Picture(){
    var arr = ["img/left2.jpg","img/left5.jpg","img/left1.jpg","img/left7.jpg"];
    var img = document.getElementById("img");
    img.src = arr[i];
    i++;
    if(i>=arr.length){
        i=0;
    }
}
var tt=setInterval("get_Picture()",1000);

/*风格展示中的关注*/
function pshow(p){
    var guanzhu = $(".guanzhu");
    for(var g = 0;g<guanzhu.length; g++){
        if(p == g){
            $(guanzhu[p]).css("display","block");
        }
    }

}
function phidden(p){
    var guanzhu = $(".guanzhu");
    for(var g = 0;g<guanzhu.length; g++){
        if(p == g){
            $(guanzhu[p]).css("display","none");
        }
    }
}

/*预约单*/
function get_yy(){
    var name1 = document.getElementById("name1").value;
    var name2 = document.getElementById("name2").value;
   var tel1 = document.getElementById("tel1").value;
    var tel2 = document.getElementById("tel2").value;
    var com1 = document.getElementById("com1").value;
    var com2 = document.getElementById("com2").value;
    var dress1 = document.getElementById("dress1").value;
    var dress2 = document.getElementById("dress2").value;
    var date1 = document.getElementById("date1").value;
    var check1 = document.getElementById("check1").value;
    var check2 = document.getElementById("check2").value;
    var check3 = document.getElementById("check3").value;
    var check4 = document.getElementById("check4").value;
    var tel1_reg = /^\d{1,11}$/;
    var tel2_reg = /^\d{1,11}$/;
  if(name1.length ==0){
      alert("请输入新郎的姓名：");
      document.getElementById("name1").select();
      return false;
  }else if(name2.length == 0){
      alert("请输入新娘的姓名：");
      document.getElementById("name2").select();
      return false;
  }else if(!(tel1_reg.test(tel1))){
      alert("请输入正确的电话号码：");
      document.getElementById("tel1").select();
      return false;
  } else if(!(tel2_reg.test(tel2))){
          alert("请输入正确的电话号码：");
          document.getElementById("tel2").select();
          return false;
  }else{
      win = open("","win","width=500,height=400,left=200,top=200,menubar=1,status=1,scrollbars=1");
      win.document.write("<body bgcolor='#ffc0cb'><h1 align='center'>预约单</h1>");
      win.document.write("<table width='460px', height='200px', border='3px',align='center'>");
      win.document.write("<tr><th colspan='2'>新郎</th><th colspan='2'>新娘</th></tr>");
      win.document.write("<tr><td>姓名</td><td>"+name1+"</td><td>姓名</td><td>"+name2+"</td></tr>");
      win.document.write("<tr><td>电话</td><td>"+tel1+"</td><td>电话</td><td>"+tel2+"</td></tr>");
      win.document.write("<tr><td>邮箱</td><td>"+com1+"</td><td>邮箱</td><td>"+com2+"</td></tr>");
      win.document.write("<tr><td>室内地点</td><td>"+dress1+"</td><td>室外地点</td><td>"+dress2+"</td></tr>");
      win.document.write("<tr><td colspan='2'>预约日期</td><td colspan='2'>"+date1+"</td></tr>");
      win.document.write("<tr><td colspan='2'>风格系列</td><td colspan='2'>"+check1,check2,check3,check4+"</td></tr>");
      win.document.write("<tr><td colspan='4' align='center'><input type='button' value='继续' />	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='取消' /></td></tr></table>")
      win.document.write("<p>温馨提示：我们会在您提交预约单后的1-2天内联系您，请您保持电话畅通！</p>");
      win.document.write("</body>");
      win.document.close();
  }
}
